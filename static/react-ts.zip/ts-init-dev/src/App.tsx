import React from "react";

const App = () => <>hello world</>;

export default App;
