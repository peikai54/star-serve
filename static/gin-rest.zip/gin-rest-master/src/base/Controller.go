package base

type Controller struct {
	Data interface{}
}
