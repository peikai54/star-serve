package base

type DBModel struct {
}

var MODEL DBModel

func (this *DBModel) init() {

}
